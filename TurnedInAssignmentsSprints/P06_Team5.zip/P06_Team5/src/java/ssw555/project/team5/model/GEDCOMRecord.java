package ssw555.project.team5.model;

public class GEDCOMRecord {
	private String uniqueId;

	public String getUniqueId() {
		return uniqueId;
	}
	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}
}